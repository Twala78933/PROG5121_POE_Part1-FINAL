/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * to change this license
 */

package com.mycompany.prog5121_poe_part1;

import java.util.Scanner;

/**
 *
 * @author Student
 */

class Login {

    String username;
    String password;
    String cellPhoneNumber;
    String firstName;
    String lastName;

    // Check username
    public boolean checkUserName() {

        return username.contains("_")
                && username.length() <= 5;
    }

    // Check password complexity
    public boolean checkPasswordComplexity() {

        if (password.length() < 8) {
            return false;
        }

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {

            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasCapital = true;
            }

            if (Character.isDigit(ch)) {
                hasNumber = true;
            }

            if (!Character.isLetterOrDigit(ch)
                    && !Character.isWhitespace(ch)) {

                hasSpecial = true;
            }
        }

        return hasCapital
                && hasNumber
                && hasSpecial;
    }

    /*
     * Regular expression reference:
     * Oracle Java Documentation - Pattern
     * https://docs.oracle.com/javase/8/docs/api/java/util/regex/Pattern.html
     */
    public boolean checkCellPhoneNumber() {

        String phoneRegex = "^\\+27\\d{9}$";

        return cellPhoneNumber.matches(phoneRegex);
    }

    // Registration messages
    public String registerUser() {

        if (!checkUserName()) {

            return "Username is not correctly formatted; "
                    + "please ensure that your username contains "
                    + "an underscore and is no more than five "
                    + "characters in length.";
        }

        if (!checkPasswordComplexity()) {

            return "Password is not correctly formatted; "
                    + "please ensure that the password contains "
                    + "at least eight characters, a capital letter, "
                    + "a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {

            return "Cell phone number incorrectly formatted "
                    + "or does not contain international code.";
        }

        return "Username successfully captured.\n"
                + "Password successfully captured.\n"
                + "Cell phone number successfully added.";
    }

    // Check login details
    public boolean loginUser(String enteredUsername,
                             String enteredPassword) {

        return username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }

    // Return login message
    public String returnLoginStatus(boolean isLoggedIn) {

        if (isLoggedIn) {

            return "Welcome "
                    + firstName
                    + ", "
                    + lastName
                    + " it is great to see you again.";

        } else {

            return "Username or password incorrect, please try again.";
        }
    }
}


public class PROG5121_POE_Part1 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Login user = new Login();

        // Registration

        System.out.print("Enter first name: ");
        user.firstName = sc.nextLine();

        System.out.print("Enter last name: ");
        user.lastName = sc.nextLine();

        System.out.print("Enter username: ");
        user.username = sc.nextLine();

        System.out.print("Enter password: ");
        user.password = sc.nextLine();

        System.out.print("Enter cell phone number: ");
        user.cellPhoneNumber = sc.nextLine();

        System.out.println();

        String registrationMessage = user.registerUser();

        System.out.println(registrationMessage);

        // Continue to login only if registration was successful
        if (user.checkUserName()
                && user.checkPasswordComplexity()
                && user.checkCellPhoneNumber()) {

            System.out.println();
            System.out.println("--- Login ---");

            System.out.print("Enter username: ");
            String loginUsername = sc.nextLine();

            System.out.print("Enter password: ");
            String loginPassword = sc.nextLine();

            boolean loginSuccessful = user.loginUser(
                    loginUsername,
                    loginPassword
            );

            System.out.println();

            System.out.println(
                    user.returnLoginStatus(loginSuccessful)
            );
        }

        sc.close();
    }
}