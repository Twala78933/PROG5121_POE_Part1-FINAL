package com.mycompany.prog5121_poe_part1;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

// Part 1: registration and login.
class Login {
    String username;
    String password;
    String cellPhoneNumber;
    String firstName;
    String lastName;

    public boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) return false;

        boolean capital = false, number = false, special = false;
        for (char letter : password.toCharArray()) {
            if (Character.isUpperCase(letter)) capital = true;
            if (Character.isDigit(letter)) number = true;
            if (!Character.isLetterOrDigit(letter) && !Character.isWhitespace(letter)) {
                special = true;
            }
        }
        return capital && number && special;
    }

    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber != null && cellPhoneNumber.matches("\\+27\\d{9}");
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username "
                    + "contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password "
                    + "contains at least eight characters, a capital letter, a number, "
                    + "and a special character.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        return "Username successfully captured.\nPassword successfully captured.\n"
                + "Cell phone number successfully added.";
    }

    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username != null && password != null
                && username.equals(enteredUsername) && password.equals(enteredPassword);
    }

    public String returnLoginStatus(boolean loggedIn) {
        return loggedIn
                ? "Welcome " + firstName + ", " + lastName + " it is great to see you again."
                : "Username or password incorrect, please try again.";
    }
}

// Part 2: manage QuickChat messages.
class Message {
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final Set<String> usedIDs = new HashSet<>();
    private static int totalSent = 0;

    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private int selectedAction;

    public Message(int messageNumber, String recipient, String message) {
        this(createUniqueID(), messageNumber, recipient, message);
    }

    // Package-private constructor makes the message hash test predictable.
    Message(String fixedID, int messageNumber, String recipient, String message) {
        this.messageID = fixedID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;
    }

    private static String createUniqueID() {
        String newID;
        do {
            newID = String.format(Locale.ROOT, "%010d",
                    ThreadLocalRandom.current().nextLong(10_000_000_000L));
        } while (!usedIDs.add(newID));
        return newID;
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.matches("\\d{10}");
    }

    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("\\+27\\d{9}")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }

    public String checkMessageLength() {
        if (message != null && message.length() <= 250) {
            return "Message ready to send.";
        }
        int extra = message == null ? 0 : Math.max(0, message.length() - 250);
        return "Message exceeds 250 characters by " + extra + "; please reduce the size.";
    }

    public String createMessageHash() {
        String trimmed = message == null ? "" : message.trim();
        String[] words = trimmed.isEmpty() ? new String[]{""} : trimmed.split("\\s+");
        String first = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String last = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        return (messageID.substring(0, 2) + ":" + messageNumber + ":"
                + first + last).toUpperCase(Locale.ROOT);
    }

    public void setAction(int action) {
        selectedAction = action;
    }

    // Assignment method name: SentMessage().
    public String SentMessage() {
        if (selectedAction == 2) {
            return "Press 0 to delete the message.";
        }
        if (selectedAction != 1 && selectedAction != 3) {
            return "Invalid option.";
        }
        if (message == null || message.isBlank()) {
            return "Please enter a message.";
        }
        if (message.length() > 250) {
            return checkMessageLength();
        }
        if (recipient == null || !recipient.matches("\\+27\\d{9}")) {
            return checkRecipientCell();
        }
        if (selectedAction == 3) {
            return storeMessage();
        }
        sentMessages.add(this);
        totalSent++;
        return "Message successfully sent.";
    }

    public String printMessages() {
        if (sentMessages.isEmpty()) return "No messages sent.";
        StringBuilder result = new StringBuilder();
        for (Message item : sentMessages) {
            result.append(item.getDetails()).append("\n\n");
        }
        return result.toString();
    }

    public int returnTotalMessagess() {
        return totalSent;
    }

    public String getDetails() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + createMessageHash()
                + "\nRecipient: " + recipient
                + "\nMessage: " + message;
    }

    public String getMessageID() {
        return messageID;
    }

    public String storeMessage() {
        return storeMessage(Path.of("stored_messages.json"));
    }

    // Testable overload; writes the same JSON format to a temporary file.
    String storeMessage(Path filename) {
        if (message == null || message.isBlank() || message.length() > 250
                || recipient == null || !recipient.matches("\\+27\\d{9}")) {
            return "Could not store message: invalid message details.";
        }
        try {
            String current = Files.exists(filename)
                    ? Files.readString(filename, StandardCharsets.UTF_8).trim() : "[]";
            if (!current.startsWith("[") || !current.endsWith("]")) {
                return "Could not store message: invalid JSON file.";
            }
            String existing = current.substring(1, current.length() - 1).trim();
            String jsonEntry = "  {\"messageID\":\"" + escapeJSON(messageID)
                    + "\",\"messageHash\":\"" + escapeJSON(createMessageHash())
                    + "\",\"recipient\":\"" + escapeJSON(recipient)
                    + "\",\"message\":\"" + escapeJSON(message) + "\"}";
            String content = "[\n" + (existing.isEmpty() ? "" : existing + ",\n")
                    + jsonEntry + "\n]";
            Files.writeString(filename, content, StandardCharsets.UTF_8);
            return "Message successfully stored.";
        } catch (IOException e) {
            return "Could not store message: " + e.getMessage();
        }
    }

    private String escapeJSON(String text) {
        return text.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Reset shared state between unit tests.
    static void resetForTests() {
        sentMessages.clear();
        usedIDs.clear();
        totalSent = 0;
    }
}

// Keep this name because NetBeans expects it to match the Java filename.
public class PROG5121_POE_Part1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Login user = new Login();

        System.out.print("Enter first name: ");
        user.firstName = sc.nextLine();
        System.out.print("Enter last name: ");
        user.lastName = sc.nextLine();
        System.out.print("Enter username: ");
        user.username = sc.nextLine();
        System.out.print("Enter password: ");
        user.password = sc.nextLine();
        System.out.print("Enter cell phone number (+27...): ");
        user.cellPhoneNumber = sc.nextLine();

        System.out.println("\n" + user.registerUser());
        if (!user.checkUserName() || !user.checkPasswordComplexity()
                || !user.checkCellPhoneNumber()) return;

        System.out.println("\n--- Login ---");
        System.out.print("Enter username: ");
        String enteredUsername = sc.nextLine();
        System.out.print("Enter password: ");
        String enteredPassword = sc.nextLine();
        boolean loggedIn = user.loginUser(enteredUsername, enteredPassword);
        System.out.println(user.returnLoginStatus(loggedIn));
        if (!loggedIn) return;

        startQuickChat(sc);
    }

    private static int readNumber(Scanner sc, String question) {
        while (true) {
            System.out.print(question);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
            }
        }
    }

    private static void startQuickChat(Scanner sc) {
        System.out.println("\nWelcome to QuickChat.");
        int max;
        do {
            max = readNumber(sc, "How many messages do you want to enter? ");
        } while (max < 1);

        int entered = 0;
        Message latest = null;

        while (true) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            int menu = readNumber(sc, "Choose: ");

            if (menu == 3) {
                System.out.println("Total messages sent: "
                        + (latest == null ? 0 : latest.returnTotalMessagess()));
                System.out.println("Goodbye!");
                break;
            }
            if (menu == 2) {
                System.out.println("Coming Soon.");
                continue;
            }
            if (menu != 1) {
                System.out.println("Invalid option.");
                continue;
            }
            if (entered >= max) {
                System.out.println("You have entered the maximum number of messages.");
                continue;
            }

            System.out.print("Recipient number (+27...): ");
            String recipient = sc.nextLine();
            System.out.print("Enter message: ");
            String body = sc.nextLine();
            Message current = new Message(entered, recipient, body);
            latest = current;
            System.out.println("Message ID generated: " + current.getMessageID());

            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            int action = readNumber(sc, "Choose: ");
            current.setAction(action);
            String result = current.SentMessage();
            System.out.println(result);

            if (result.equals("Message successfully sent.")) {
                System.out.println(current.getDetails());
                entered++;
            } else if (result.equals("Message successfully stored.")) {
                entered++;
            } else if (action == 2) {
                if (readNumber(sc, "Press 0 to delete the message: ") == 0) {
                    System.out.println("Message discarded.");
                    entered++;
                } else {
                    System.out.println("Message not discarded.");
                }
            }

            if (entered == max) {
                System.out.println("Total messages sent: " + current.returnTotalMessagess());
            }
        }
    }
}
