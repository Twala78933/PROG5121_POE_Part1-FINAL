package com.mycompany.prog5121_poe_part1;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import static org.junit.jupiter.api.Assertions.*;

class MessageTest {
    @BeforeEach
    void reset() {
        Message.resetForTests();
    }

    @Test
    void messageWithin250Characters() {
        Message msg = new Message(0, "+27718693002", "A".repeat(250));
        assertEquals("Message ready to send.", msg.checkMessageLength());
    }

    @Test
    void messageOver250Characters() {
        Message msg = new Message(0, "+27718693002", "A".repeat(255));
        assertEquals("Message exceeds 250 characters by 5; please reduce the size.",
                msg.checkMessageLength());
    }

    @Test
    void recipientWithInternationalCodeAccepted() {
        Message msg = new Message(0, "+27718693002", "Hello");
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell());
    }

    @Test
    void recipientWithoutInternationalCodeRejected() {
        Message msg = new Message(1, "08575975889", "Hello");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                msg.checkRecipientCell());
    }

    @Test
    void sampleMessageHash() {
        Message msg = new Message("0012345678", 0, "+27718693002",
                "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", msg.createMessageHash());
    }

    @Test
    void everyGeneratedMessageIdHasTenDigitsAndIsUnique() {
        Set<String> ids = new HashSet<>();
        for (int i = 0; i < 200; i++) {
            Message msg = new Message(i, "+27718693002", "Test");
            assertTrue(msg.checkMessageID());
            assertTrue(ids.add(msg.getMessageID()));
        }
    }

    @Test
    void sendingMessageIncreasesSentCount() {
        Message msg = new Message(0, "+27718693002", "Hello Mike");
        msg.setAction(1);
        assertEquals("Message successfully sent.", msg.SentMessage());
        assertEquals(1, msg.returnTotalMessagess());
        assertTrue(msg.printMessages().contains("Hello Mike"));
        assertTrue(msg.getDetails().contains("Message Hash:"));
    }

    @Test
    void discardingMessageDoesNotIncreaseSentCount() {
        Message msg = new Message(1, "08575975889",
                "Hi Keegan, did you receive the payment?");
        msg.setAction(2);
        assertEquals("Press 0 to delete the message.", msg.SentMessage());
        assertEquals(0, msg.returnTotalMessagess());
    }

    @Test
    void storingMessageAsJsonPreservesExistingMessages(@TempDir Path folder) throws Exception {
        Path file = folder.resolve("stored_messages.json");
        Message first = new Message("0012345678", 0, "+27718693002", "Hi Mike");
        Message second = new Message("9912345678", 1, "+27718693002", "Hi Keegan");
        assertEquals("Message successfully stored.", first.storeMessage(file));
        assertEquals("Message successfully stored.", second.storeMessage(file));
        String json = Files.readString(file);
        assertTrue(json.trim().startsWith("["));
        assertTrue(json.trim().endsWith("]"));
        assertTrue(json.contains("Hi Mike"));
        assertTrue(json.contains("Hi Keegan"));
        assertTrue(json.contains("\"messageHash\""));
        assertEquals(0, first.returnTotalMessagess());
    }

    @Test
    void jsonEscapesDoubleQuotes(@TempDir Path folder) throws Exception {
        Path file = folder.resolve("stored_messages.json");
        Message msg = new Message("0012345678", 0, "+27718693002", "He said \"Hello\"");
        assertEquals("Message successfully stored.", msg.storeMessage(file));
        assertTrue(Files.readString(file).contains("\\\"Hello\\\""));
    }

    @Test
    void tooLongMessageCannotBeSent() {
        Message msg = new Message(0, "+27718693002", "A".repeat(251));
        msg.setAction(1);
        assertEquals("Message exceeds 250 characters by 1; please reduce the size.",
                msg.SentMessage());
        assertEquals(0, msg.returnTotalMessagess());
    }

    @Test
    void invalidPhoneCannotBeSent() {
        Message msg = new Message(0, "08575975889", "Hello");
        msg.setAction(1);
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
                msg.SentMessage());
        assertEquals(0, msg.returnTotalMessagess());
    }
}
