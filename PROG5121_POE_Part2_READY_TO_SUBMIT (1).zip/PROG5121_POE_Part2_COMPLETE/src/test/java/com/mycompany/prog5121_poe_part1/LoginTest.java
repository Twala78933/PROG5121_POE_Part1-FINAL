package com.mycompany.prog5121_poe_part1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class LoginTest {
    private Login validLogin() {
        Login user = new Login();
        user.firstName = "Xivono";
        user.lastName = "Twala";
        user.username = "ab_12";
        user.password = "Hello@123";
        user.cellPhoneNumber = "+27718693002";
        return user;
    }

    @Test
    void usernameMustContainUnderscoreAndBeAtMostFiveCharacters() {
        Login user = validLogin();
        assertTrue(user.checkUserName());
        user.username = "abcdef";
        assertFalse(user.checkUserName());
    }

    @Test
    void passwordMustContainRequiredCharacters() {
        Login user = validLogin();
        assertTrue(user.checkPasswordComplexity());
        user.password = "helloworld";
        assertFalse(user.checkPasswordComplexity());
    }

    @Test
    void validInternationalCellNumberIsAccepted() {
        assertTrue(validLogin().checkCellPhoneNumber());
    }

    @Test
    void loginRequiresMatchingUsernameAndPassword() {
        Login user = validLogin();
        assertTrue(user.loginUser("ab_12", "Hello@123"));
        assertFalse(user.loginUser("ab_12", "Wrong@123"));
    }
}
