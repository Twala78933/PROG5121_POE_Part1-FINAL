# PROG5121 — POE Part 2: QuickChat

Java Maven application extending Part 1 registration and login with QuickChat message sending, discarding, local JSON storage, generated message IDs/hashes, and a three-option menu.

## Import into NetBeans

1. Extract the downloaded ZIP. Keep the folder structure.
2. In Apache NetBeans choose **File > Open Project**.
3. Select the extracted `PROG5121_POE_Part2_COMPLETE` folder (it contains `pom.xml`).
4. Right-click the project and select **Run** (or press F6). If asked to choose a main class, select `com.mycompany.prog5121_poe_part1.PROG5121_POE_Part1`.
5. Right-click the project and select **Test**. Maven will download JUnit the first time, so internet access is needed.

**Note:** The Java file/class is still named `PROG5121_POE_Part1.java` so the existing main class and package stay compatible with Part 1. The Maven project is named Part 2.

### Test login details

- First name: Xivono
- Last name: Twala
- Username: `ab_12`
- Password: `Hello@123`
- Cell number: `+27718693002`
- Re-enter the *same* username and password when asked to log in.

### Assignment sample

Choose **2 messages**. For the first, use recipient `+27718693002` and text `Hi Mike, can you join us for dinner tonight?`, then **Send**. For the second, use `+27857597588` and text `Hi Keegan, did you receive the payment?`, then **Disregard**, followed by **0**. Exactly **1 message** should be sent. `+27857597588` is used instead of the domestic-formatted test input because the assignment also asks for international-code validation; discarding will also work with the provided invalid domestic-formatted number.

### File storage

Choose **Store Message** to write JSON to `stored_messages.json` in the program's working directory. Stored messages are not sent, so they do not increase the sent count. No real SMS or instant messages are sent; this is a simulated coursework app.

### Tests / CI

- JUnit 5 tests: `src/test/java/com/mycompany/prog5121_poe_part1/MessageTest.java` and `LoginTest.java` (16 test cases).
- GitHub Actions workflow: `.github/workflows/java-tests.yml`.
- Workflow runs `mvn clean verify` on every push and pull request.

### GitHub upload & submission

1. Open your **existing Part 1 GitHub repository**. Create a branch called `part2-quickchat` from `main` and select it.
2. Upload the CONTENTS of this extracted project to the ROOT of that branch: `pom.xml`, `src/`, `.github/`, `.gitignore`, and `README.md`. Preserve the folder hierarchy. Overwrite the old Java file on the branch, **not** on `main`.
3. Commit with message `Complete PROG5121 POE Part 2`.
4. Open the **Actions** tab. Check that `Test QuickChat Part 2` has a green check. If not, read the log and fix before submitting.
5. Submit the **GitHub branch link** (ending with `/tree/part2-quickchat`) or a pull-request link if your lecturer asks for a PR. Check your student portal's exact submission format; do not submit just the ZIP if a GitHub link is required.

GitHub workflow runs only after you actually upload the files to your repository. This downloaded ZIP is not itself a GitHub submission.
